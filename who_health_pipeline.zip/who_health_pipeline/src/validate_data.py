# src/validate_data.py

import os
import json
import pandas as pd
import pandera as pa
from pandera import Column, DataFrameSchema, Check

RAW_DATA_PATH = os.path.join("data", "raw_data.json")
VALIDATED_DATA_PATH = os.path.join("data", "validated_data.csv")

# Definimos el esquema esperado
schema = DataFrameSchema({
    "IndicatorCode": Column(str, nullable=False),
    "Location": Column(str, nullable=False),
    "Period": Column(int, Check.ge(1900), nullable=False),
    "Value": Column(float, Check.ge(0), nullable=False),
    "Dim1": Column(str, nullable=True),  # Sexo: puede faltar
})

def validate_data(raw_path=RAW_DATA_PATH, output_path=VALIDATED_DATA_PATH):
    with open(raw_path, "r", encoding="utf-8") as f:
        raw = json.load(f)
        records = raw["value"]
        df = pd.DataFrame(records)

    # Validamos el DataFrame
    df_validated = schema.validate(df)

    # Guardamos como CSV validado
    df_validated.to_csv(output_path, index=False)
    print(f"Datos validados guardados en {output_path}")

if __name__ == "__main__":
    validate_data()
