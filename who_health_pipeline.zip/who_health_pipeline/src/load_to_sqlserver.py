# src/load_data.py

import os
import pandas as pd
import psycopg2
from dotenv import load_dotenv
from sqlalchemy import create_engine

# Cargamos variables de entorno
load_dotenv()

DB_USER = os.getenv("POSTGRES_USER", "airflow")
DB_PASSWORD = os.getenv("POSTGRES_PASSWORD", "airflow")
DB_HOST = os.getenv("POSTGRES_HOST", "postgres")  # Nombre del servicio en docker-compose
DB_PORT = os.getenv("POSTGRES_PORT", "5432")
DB_NAME = os.getenv("POSTGRES_DB", "airflow")

TABLE_NAME = "who_health_data"
DATA_PATH = os.path.join("data", "transformed_data.csv")

def load_data():
    df = pd.read_csv(DATA_PATH)

    engine = create_engine(f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}")

    with engine.connect() as conn:
        df.to_sql(TABLE_NAME, conn, if_exists="replace", index=False)
        print(f"Datos cargados correctamente en la tabla '{TABLE_NAME}'")

if __name__ == "__main__":
    load_data()
